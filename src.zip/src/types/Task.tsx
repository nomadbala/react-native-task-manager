type Task = {
  id: string | number[];
  title: string;
  description: string | null;
  status: boolean;
};

export default Task;
